# DAvanceloader v5 — End-User Notice

DAvanceloader v5 is provided under the Apache License, Version 2.0, included in [LICENSE](LICENSE). This notice is informational and does not impose additional restrictions on rights granted by that license. If there is any conflict, the Apache License controls.

## Use and third-party websites

You are responsible for the addresses you choose to load and for complying with applicable laws and the terms of the websites you access. Third-party websites and their content are not part of DAvanceloader and are governed by their respective owners' terms and privacy practices. The application does not bypass browser-enforced embedding restrictions.

## Local data and permissions

The application may store recent addresses in your browser and allows you to export them. Addresses can contain private information. Clipboard, fullscreen, browser storage, and access to external websites depend on your browser and environment. Silent iframe mode hides visuals but does not stop the page or mute audio.

## No warranty

The software is provided on an **AS IS** basis, without warranties or conditions of any kind, as described in the Apache License. The limitations of liability in that license apply. Nothing in this notice excludes rights or remedies that cannot legally be excluded.

## Names and trademarks

The Apache License does not grant trademark rights except as stated in the license. Names and marks of third-party websites belong to their respective owners; their appearance does not imply endorsement.
