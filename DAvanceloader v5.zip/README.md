# DAvanceloader v5

A browser-based workspace for previewing websites in an iframe. Enter an HTTP or HTTPS address, then adjust the viewport and iframe settings to explore how a page appears at different sizes.

## Features

- Responsive, desktop, tablet, phone, and custom viewport sizes; swap dimensions, scale, center, and outline the preview.
- Dotted, dark, and light preview backdrops.
- Silent iframe mode hides the page without unloading it. It does **not** mute audio or stop scripts, network activity, or resource usage.
- Optional iframe sandbox permissions and selectable referrer policy. Policy changes apply on the next load.
- Reload, unload, fullscreen, clipboard actions, and a direct link to open the address in a new tab.
- Up to eight recent addresses, stored locally when browser storage is available, with JSON import and export.

## Important limitations

DAvanceloader cannot bypass a site's `X-Frame-Options` or Content Security Policy (`frame-ancestors`) restrictions. An iframe load event does not prove that a site displayed successfully, and browsers generally do not let this application inspect cross-origin frame errors or contents. Some sites may also fail because of mixed-content rules, authentication, cookies, sandbox settings, or other browser and website policies. Use the new-tab link when embedding is unavailable.

The application itself has no backend or proxy. Loading an external website requires network access, and that website can receive requests and collect data according to its own policies. Clipboard and fullscreen features depend on browser permissions and the embedding environment.

## Privacy and history

Recent URLs are saved in the browser's local storage when available; otherwise they remain in memory for the session. URLs may contain sensitive paths or query parameters. Clear history when appropriate, and treat exported history files as sensitive. Clearing history does not erase browser history, downloads, server logs, or data held by websites you visit.

## License

The source is available under the [Apache License, Version 2.0](LICENSE). See [EULA.md](EULA.md) for a plain-language end-user notice; it does not replace or restrict the Apache license. No affiliation with, or endorsement by, any website displayed in the preview is implied.
