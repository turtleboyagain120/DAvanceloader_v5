const form = document.getElementById('loaderForm');
const urlInput = document.getElementById('pageUrl');
const frame = document.getElementById('pageFrame');
const frameWrap = document.getElementById('frameWrap');
const silentOverlay = document.getElementById('silentOverlay');
const silentMode = document.getElementById('silentMode');
const statusText = document.getElementById('status');
const statusDot = document.getElementById('statusDot');
const welcome = document.getElementById('welcome');
const pageName = document.getElementById('pageName');
const pageAddress = document.getElementById('pageAddress');
const reloadButton = document.getElementById('reloadButton');
const copyButton = document.getElementById('copyButton');
const openButton = document.getElementById('openButton');
const historyList = document.getElementById('historyList');
const emptyHistory = document.getElementById('emptyHistory');
const clearHistoryButton = document.getElementById('clearHistory');
const viewport = document.getElementById('viewport');
const preset = document.getElementById('viewportPreset');
const viewportWidth = document.getElementById('viewportWidth');
const viewportHeight = document.getElementById('viewportHeight');
const zoom = document.getElementById('zoom');
const centerViewport = document.getElementById('centerViewport');
const frameBorder = document.getElementById('frameBorder');
const backdrop = document.getElementById('backdrop');
const sandboxEnabled = document.getElementById('sandboxEnabled');
const sandboxOptions = document.getElementById('sandboxOptions');
const referrerPolicy = document.getElementById('referrerPolicy');
const unloadButton = document.getElementById('unloadButton');
const historyFile = document.getElementById('historyFile');

const HISTORY_KEY = 'framelab.recent-pages';
const MAX_HISTORY = 8;
let currentUrl = '';
let loadTimer;
let history = [];

try {
  const saved = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
  if (Array.isArray(saved)) {
    history = saved.filter((item) => {
      if (typeof item !== 'string') return false;
      try {
        normalizeUrl(item);
        return true;
      } catch {
        return false;
      }
    }).map((item) => normalizeUrl(item).href).filter((item, index, items) => items.indexOf(item) === index).slice(0, MAX_HISTORY);
  }
} catch {
  // Keep an in-memory history when storage is unavailable.
}

function readHistory() {
  return history;
}

function setStatus(message, state = '') {
  statusText.textContent = message;
  statusDot.className = `status-dot${state ? ` ${state}` : ''}`;
}

function normalizeUrl(value) {
  const trimmed = value.trim();
  if (!trimmed) throw new Error('Enter a website address.');

  const hasHostPort = /^(?:\[[\da-f:.]+\]|[^/?#:\s]+):\d+(?:[/?#]|$)/i.test(trimmed);
  const hasScheme = /^[a-z][a-z\d+.-]*:/i.test(trimmed);
  const candidate = hasScheme && !hasHostPort ? trimmed : `https://${trimmed}`;
  let parsed;
  try {
    parsed = new URL(candidate);
  } catch {
    throw new Error('That address does not look valid. Check it and try again.');
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Only HTTP and HTTPS website addresses are supported.');
  }
  if (!parsed.hostname || parsed.username || parsed.password) {
    throw new Error('Enter a website address without sign-in details.');
  }
  return parsed;
}

function saveHistory(url) {
  const next = [url, ...readHistory().filter((item) => item !== url)].slice(0, MAX_HISTORY);
  history = next;
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
  } catch {
    // The preview still works when browser storage is unavailable.
  }
  renderHistory(next);
}

function renderHistory(items = readHistory()) {
  historyList.replaceChildren();
  emptyHistory.hidden = items.length > 0;
  clearHistoryButton.hidden = items.length === 0;

  items.forEach((item) => {
    let parsed;
    try {
      parsed = normalizeUrl(item);
    } catch {
      return;
    }

    const row = document.createElement('li');
    row.className = 'history-item';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'history-link';
    button.title = parsed.href;

    const icon = document.createElement('span');
    icon.className = 'history-favicon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = parsed.hostname.charAt(0).toUpperCase();

    const text = document.createElement('span');
    text.className = 'history-text';
    const host = document.createElement('span');
    host.className = 'history-host';
    host.textContent = parsed.hostname;
    const path = document.createElement('span');
    path.className = 'history-path';
    path.textContent = parsed.pathname + parsed.search;
    text.append(host, path);
    button.append(icon, text);
    button.addEventListener('click', () => loadPage(parsed.href));
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'history-remove';
    remove.textContent = '×';
    remove.setAttribute('aria-label', `Remove ${parsed.hostname} from history`);
    remove.addEventListener('click', () => {
      history = history.filter((entry) => entry !== item);
      persistHistory();
    });
    row.append(button, remove);
    historyList.append(row);
  });
}

function loadPage(value) {
  let parsed;
  try {
    parsed = normalizeUrl(value);
  } catch (error) {
    setStatus(error.message, 'warning');
    urlInput.focus();
    return;
  }

  currentUrl = parsed.href;
  urlInput.value = currentUrl;
  pageName.textContent = parsed.hostname;
  pageAddress.textContent = currentUrl;
  openButton.href = currentUrl;
  openButton.removeAttribute('aria-disabled');
  openButton.removeAttribute('tabindex');
  reloadButton.disabled = false;
  copyButton.disabled = false;
  welcome.hidden = true;
  viewport.hidden = false;
  frame.hidden = false;
  unloadButton.disabled = false;
  applyFramePolicies();
  frameWrap.classList.toggle('silent-mode', silentMode.checked);
  silentOverlay.hidden = !silentMode.checked;
  frame.src = currentUrl;
  setStatus('Request sent. Waiting for the embedded page…', 'loading');
  clearTimeout(loadTimer);
  loadTimer = setTimeout(() => {
    setStatus('Still waiting. The site may be slow or may restrict iframe embedding.', 'warning');
  }, 10000);
  saveHistory(currentUrl);
}

frame.addEventListener('load', () => {
  if (!currentUrl) return;
  clearTimeout(loadTimer);
  setStatus('Frame load event received. This does not confirm the site allowed embedding.', '');
});

form.addEventListener('submit', (event) => {
  event.preventDefault();
  loadPage(urlInput.value);
});

silentMode.addEventListener('change', () => {
  frameWrap.classList.toggle('silent-mode', silentMode.checked);
  silentOverlay.hidden = !silentMode.checked || !currentUrl;
  if (currentUrl) {
    setStatus(silentMode.checked
      ? 'Silent iframe is on. The page remains loaded and may still use resources or play audio.'
      : 'Silent iframe is off. The frame is visible again; embedding is not guaranteed.', silentMode.checked ? 'warning' : '');
  }
});

reloadButton.addEventListener('click', () => {
  if (currentUrl) loadPage(currentUrl);
});

copyButton.addEventListener('click', async () => {
  if (!currentUrl) return;
  try {
    await navigator.clipboard.writeText(currentUrl);
    setStatus('Page address copied to clipboard.', 'ready');
  } catch {
    setStatus('Clipboard access is unavailable. Select and copy the address from the input.', 'warning');
    urlInput.focus();
    urlInput.select();
  }
});

clearHistoryButton.addEventListener('click', () => {
  history = [];
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch {
    // Clearing the visible list is still useful if storage is unavailable.
  }
  renderHistory([]);
});

renderHistory();
updateViewport();
updateSandboxOptions();

function persistHistory() {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  } catch {
    // Keep changes in memory when storage is unavailable.
  }
  renderHistory();
}

function updateViewport() {
  const scale = Number(zoom.value) / 100;
  const responsive = preset.value === 'responsive';
  const width = Math.min(4000, Math.max(200, Number(viewportWidth.value) || 200));
  const height = Math.min(4000, Math.max(200, Number(viewportHeight.value) || 200));
  viewportWidth.value = width;
  viewportHeight.value = height;
  viewportWidth.disabled = responsive;
  viewportHeight.disabled = responsive;
  viewport.style.width = responsive ? '100%' : `${width * scale}px`;
  viewport.style.height = responsive ? '100%' : `${height * scale}px`;
  frame.style.width = responsive ? `${100 / scale}%` : `${width}px`;
  frame.style.height = responsive ? `${100 / scale}%` : `${height}px`;
  frame.style.transform = `scale(${scale})`;
  viewport.classList.toggle('centered', !responsive && centerViewport.checked);
  viewport.classList.toggle('outlined', frameBorder.checked);
  frameWrap.classList.toggle('backdrop-dark', backdrop.value === 'dark');
  frameWrap.classList.toggle('backdrop-light', backdrop.value === 'light');
  document.getElementById('zoomValue').textContent = `${zoom.value}%`;
}

preset.addEventListener('change', () => {
  const sizes = { desktop: [1440, 900], tablet: [768, 1024], phone: [390, 844] };
  if (sizes[preset.value]) [viewportWidth.value, viewportHeight.value] = sizes[preset.value];
  updateViewport();
});
[viewportWidth, viewportHeight].forEach((input) => input.addEventListener('change', () => {
  preset.value = 'custom';
  updateViewport();
}));
document.getElementById('rotateButton').addEventListener('click', () => {
  if (preset.value === 'responsive') preset.value = 'custom';
  [viewportWidth.value, viewportHeight.value] = [viewportHeight.value, viewportWidth.value];
  preset.value = 'custom';
  updateViewport();
});
[zoom, centerViewport, frameBorder, backdrop].forEach((control) => control.addEventListener('input', updateViewport));

function updateSandboxOptions() {
  sandboxOptions.querySelectorAll('input').forEach((input) => { input.disabled = !sandboxEnabled.checked; });
}
sandboxEnabled.addEventListener('change', updateSandboxOptions);

function applyFramePolicies() {
  frame.referrerPolicy = referrerPolicy.value;
  if (!sandboxEnabled.checked) {
    frame.removeAttribute('sandbox');
    return;
  }
  const permissions = [
    ['allowScripts', 'allow-scripts'], ['allowForms', 'allow-forms'],
    ['allowPopups', 'allow-popups'], ['allowSameOrigin', 'allow-same-origin']
  ];
  frame.setAttribute('sandbox', permissions.filter(([id]) => document.getElementById(id).checked).map(([, token]) => token).join(' '));
}

document.getElementById('pasteButton').addEventListener('click', async () => {
  try {
    if (!navigator.clipboard?.readText) throw new Error('Clipboard unavailable');
    urlInput.value = await navigator.clipboard.readText();
    urlInput.focus();
    setStatus('Address pasted. Review it and load the preview.', 'ready');
  } catch {
    urlInput.focus();
    setStatus('Clipboard access is unavailable. Paste the address into the field.', 'warning');
  }
});

document.getElementById('fullscreenButton').addEventListener('click', async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else if (frameWrap.requestFullscreen) await frameWrap.requestFullscreen();
    else throw new Error('Fullscreen unavailable');
  } catch {
    setStatus('Fullscreen is unavailable in this browser or embedding environment.', 'warning');
  }
});

unloadButton.addEventListener('click', () => {
  clearTimeout(loadTimer);
  currentUrl = '';
  frame.removeAttribute('src');
  frame.hidden = true;
  viewport.hidden = true;
  welcome.hidden = false;
  silentOverlay.hidden = true;
  pageName.textContent = 'No page loaded';
  pageAddress.textContent = 'Enter an address to get started';
  reloadButton.disabled = true;
  copyButton.disabled = true;
  unloadButton.disabled = true;
  openButton.href = '#';
  openButton.setAttribute('aria-disabled', 'true');
  openButton.setAttribute('tabindex', '-1');
  setStatus('Preview unloaded.', '');
});

document.getElementById('exportHistory').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(history, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'davanceloader-history.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  setStatus('History export started.', 'ready');
});
document.getElementById('importHistory').addEventListener('click', () => historyFile.click());
historyFile.addEventListener('change', async () => {
  const file = historyFile.files[0];
  if (!file) return;
  try {
    if (file.size > 128 * 1024) throw new Error('File is too large.');
    const entries = JSON.parse(await file.text());
    if (!Array.isArray(entries) || !entries.every((entry) => typeof entry === 'string')) throw new Error('Expected an array of addresses.');
    const valid = entries.map((entry) => normalizeUrl(entry).href);
    history = [...new Set([...valid, ...history])].slice(0, MAX_HISTORY);
    persistHistory();
    setStatus('History imported; up to eight recent addresses are kept.', 'ready');
  } catch {
    setStatus('Could not import history. Choose a JSON array of valid HTTP(S) addresses under 128 KB.', 'warning');
  } finally {
    historyFile.value = '';
  }
});
